package com.alien.employee;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ch.qos.logback.core.util.Duration;

@Service
public class EmployeeService {

	@Autowired
	EmployeeRepo employeeRepo;
	int EL,year,countday,gratuity=0,total;
	public int getAmout(int id,int cbp)
	{
		//fetching employee from DB on based of employee ID
		Employee emp=employeeRepo.getById(id);
		
		//get DOJ from DB
		Date doj=emp.getDoj();
		Date cdate=new Date();
		
		long days=doj.getTime()-cdate.getTime();
	
		year=(int)days/365;
		countday=(int)days%365;
		if(year>4)
		{
			gratuity=cbp*year*15/26;
		}
		
		if(year>1)
		{
			EL=30+countday/10;
			
		}
		//each EL would be for 100;
		total=gratuity+EL+100;
		return total;
		
		
		
		
	}
	
	
}
