package com.alien.employee;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Employee {
 
	@Id
	private int eid;
	private Date doj;
	private int cbp;
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public Date getDoj() {
		return doj;
	}
	public void setDoj(Date doj) {
		this.doj = doj;
	}
	public int getCbp() {
		return cbp;
	}
	public void setCbp(int cbp) {
		this.cbp = cbp;
	}
	public Employee(int eid, Date doj, int cbp) {
		super();
		this.eid = eid;
		this.doj = doj;
		this.cbp = cbp;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
}
