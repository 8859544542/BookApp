package com.alien.employee;

import javax.persistence.criteria.CriteriaBuilder.In;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;




@Controller
public class EmployeeController {

	
	@Autowired
	EmployeeService employeeService;
	
	
	@RequestMapping("/")
	public String home()
	{
		System.out.println(".....................");
		return "employeeHome.jsp";
	}
	
	
	@RequestMapping("/getAmount")
	public ModelAndView show(@RequestParam("id") Integer id,@RequestParam("cbp") Integer cbp)
	{
		ModelAndView mv=new ModelAndView();
		Integer totalamount=employeeService.getAmout(id,cbp);
		System.out.println(totalamount);
		mv.addObject(totalamount);
		mv.setViewName("showAmount.jsp");
		return mv;
		
		
	}
}
