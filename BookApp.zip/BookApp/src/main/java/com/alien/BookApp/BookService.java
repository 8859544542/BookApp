package com.alien.BookApp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookService {
     
	@Autowired
	BookRepo bookrepo;
	
	public Book addBook(Book book)
	{
		
		bookrepo.save(book);
		return book;
	}
	
	
	public Book getBook(int id) 
	{
		
		Book book=bookrepo.getById(id);
		return book;
		
	}
}
