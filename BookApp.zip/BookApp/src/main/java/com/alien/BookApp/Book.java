package com.alien.BookApp;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Component
@Entity
public class Book {

	@Id
	private int id;
	private String name;
	private String genere;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGenere() {
		return genere;
	}
	public void setGenere(String genere) {
		this.genere = genere;
	}
	@Override
	public String toString() {
		return "Book [id=" + id + ", name=" + name + ", genere=" + genere + "]";
	}
	public Book(int id, String name, String genere) {
		super();
		this.id = id;
		this.name = name;
		this.genere = genere;
	}
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
