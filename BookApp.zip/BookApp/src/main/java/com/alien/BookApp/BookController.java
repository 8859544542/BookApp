package com.alien.BookApp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;




@Controller
public class BookController {

	@Autowired
	BookService bookService;
	@Autowired
	Book book;
	
	
	@RequestMapping("/")
	public String home()
	{
		System.out.println(".....................");
		return "homebook.jsp";
	}
	
	@RequestMapping("/addBook")
	@ResponseBody
	public String addBook(@RequestParam("id") int id, @RequestParam("name") String name,@RequestParam("genere") String genere)
	{
		System.out.println("in addbook ....");
		
		book.setId(id);
		book.setName(name);
		book.setGenere(genere);
		
		bookService.addBook(book);
		
		return "data added successfully in DB";
		
		
	}
	

	@RequestMapping("/getBook")
	public ModelAndView show(@RequestParam("id") Integer id)
	{
		ModelAndView mv=new ModelAndView();
		Book book=bookService.getBook(id);
		System.out.println(book);
		mv.addObject(book);
		mv.setViewName("showbook.jsp");
		return mv;
		
		
	}
	
}
