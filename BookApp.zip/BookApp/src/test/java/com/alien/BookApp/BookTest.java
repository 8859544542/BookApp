package com.alien.BookApp;


import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

public class BookTest {

	


	BookService bookService=new BookService();
	
	@Test
	public void testName()
	{
		 System.out.println(bookService.getBook(100).getName());
	 assertEquals("Dreams",bookService.getBook(100).getName());
	
		
	}
}
